#!/bin/bash

# For personal project @deb:xorg

DIR="$(dirname $(readlink -f '$0'))"

recolor(){
  local ORIG="$1"
  local REPL="$2"
  for SVG in $(find $DIR | grep .svg); do
    if ! [ -z "$(cat $SVG | grep $ORIG)" ]; then
      echo "Updating $SVG."
      sed -i "s/$ORIG/$REPL/" $SVG
    fi
  done
}

# Blue
recolor "#2d8cff" "#0058ff"
recolor "#67b7ff" "#0078ff"

# Red
recolor "#d43838" "#d63232"

# Yellow
recolor "#ffa803" "#ffff55"

# Cyan
recolor "#00c28e" "#008888"

# Brown
recolor "#ebb16d" "#ebbd6d" 
recolor "#a56b50" "#a78952"
