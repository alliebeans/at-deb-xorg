## Special thanks to this patrons and supporters:

 - Justin Shepherd ★
 - Daniel Evertsson ★
 - Ángel Álvarez ★
 - José Rodrí­guez ★
 - Fran J. Clemente ★
 - Danail Irinchev ★
 - Nick Bonczyk ★

 - Niivu ☆
 - Dimitry Zamyslov
 - Adolfo Silerio
 - Gustavo Costa
 - vince liuice
 - Fabián Alexis


---
*(If you don't want to appear in this list, please, contact me to christiandiaz.design@gmail.com)*
