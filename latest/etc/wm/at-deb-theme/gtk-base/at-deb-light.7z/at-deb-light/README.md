# cloudy-alliebeans-light
License: GPLv3

This is a gtk theme based on Cloudy-Gtk-Themes by user [g-nome](https://www.pling.com/u/g-nome) @ pling.com, with modifications by me.
