# at-deb-dark
License: GPLv3

This is a dark gray GTK theme with cyan accents based on [Cloudy-Grey-Dark](https://github.com/i-mint/Cloudy).