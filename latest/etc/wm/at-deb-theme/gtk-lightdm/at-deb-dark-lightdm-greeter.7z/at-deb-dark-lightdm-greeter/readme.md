# at-deb-dark-lightdm-greeter

License: GPLv3

This is a GTK theme for LightDM with elements taken from Cloudy-Gtk-Themes by user [g-nome](https://www.pling.com/u/g-nome) @ pling.com.
